package com.cachamor.taresem2;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;

public class Confirmar extends AppCompatActivity {

    private TextInputEditText txEdiNombre;
    private TextInputEditText txEdiFecha;
    private TextInputEditText txEdiTelefono;
    private TextInputEditText txEdiEmail;
    private TextInputEditText txEdiDescripcion;
    String stNombre,stTelefono,stEmail,stFecha,stDescripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirmar);

        //Recuperar parametros
        Bundle parametros = getIntent().getExtras();
        //
        String pnombre  = parametros.getString(getResources().getString(R.string.pnombre));
        String pfecha   = parametros.getString(getResources().getString(R.string.pfecha));
        String ptelefono= parametros.getString(getResources().getString(R.string.ptelefono));
        String pemail   = parametros.getString(getResources().getString(R.string.pemail));
        String pdescripcion   = parametros.getString(getResources().getString(R.string.pdescripcion));
        //Tomar referencia de los objetos
        txEdiNombre       = (TextInputEditText) findViewById(R.id.tieCNombre);
        txEdiFecha        = (TextInputEditText) findViewById(R.id.tieCFecha);
        txEdiTelefono     = (TextInputEditText) findViewById(R.id.tieCTelefono);
        txEdiEmail        = (TextInputEditText) findViewById(R.id.tieCEmail);
        txEdiDescripcion  = (TextInputEditText) findViewById(R.id.tieCDescripcion);
        //Asignar valores
        txEdiNombre.setText(pnombre);
        txEdiFecha.setText(pfecha);
        txEdiTelefono.setText(ptelefono);
        txEdiEmail.setText(pemail);
        txEdiDescripcion.setText(pdescripcion);
        //
        Button send = (Button) findViewById(R.id.btnEditar);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editarDatos();
            }
        });
    }

    public void editarDatos(){
        // Crear Objeto Bundle
        Bundle bunParam = new Bundle();
        bunParam.putString(getResources().getString(R.string.pnombre),txEdiNombre.getText().toString());
        bunParam.putString(getResources().getString(R.string.ptelefono),txEdiTelefono.getText().toString());
        bunParam.putString(getResources().getString(R.string.pemail),txEdiEmail.getText().toString());
        bunParam.putString(getResources().getString(R.string.pfecha),txEdiFecha.getText().toString());
        bunParam.putString(getResources().getString(R.string.pdescripcion),txEdiDescripcion.getText().toString());
        //instanciar Intent
        Intent intent = new Intent( Confirmar.this, MainActivity.class);
        //Pasar los parametros al intent
        intent.putExtras(bunParam);
        //iniciar la actividad
        startActivity(intent);
        //Finalizar actividad anterior
        finish();
    }
}
